const API_URL = '/api/analytics'
