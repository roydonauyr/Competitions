const API_URL = '/api/instruments'
