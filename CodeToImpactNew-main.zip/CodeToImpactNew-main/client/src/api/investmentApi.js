const API_URL = '/api/investments'
