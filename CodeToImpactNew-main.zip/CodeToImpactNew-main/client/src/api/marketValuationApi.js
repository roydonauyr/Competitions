const API_URL = '/api/marketValuations'
