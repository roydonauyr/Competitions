const mongoose = require('mongoose')

const instrumentSchema = mongoose.Schema({
  code: {
    type: String,
    required: true,
    unique: true,
  },
  name: {
    type: String,
    required: true,
  },
  price: {
    type: Number,
    required: true,
  },
  type: {
    type: String,
    required: true,
  },
})

module.exports = mongoose.model('Instrument', instrumentSchema)
